module.exports = app => {
  const Assigjobcontroller = require("../../controller/AssignJobcontroller");

  app.post("/api/assignjob", Assigjobcontroller.AssignJOB);
  app.get(
    "/api/assignjob/freelancer/:id",
    Assigjobcontroller.getAssigedjobbyFreelancer
  );
  app.get("/api/assignjob/client/:id", Assigjobcontroller.getAssignJObbyclient);
  app.get("/api/getanyuser/:id", Assigjobcontroller.GetAssigJobs);
};
