const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const keys = require('../config/keys');
// Load input validation
const validateRegisterInput = require('../validation/register');
const validateLoginInput = require('../validation/login');
// Load User model
const User = require('../model/User');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'rs2321994@gmail.com',
    pass: 'Devang@8688',
  },
});

exports.registeruser = async (req, res) => {
  const {errors, isValid} = validateRegisterInput(req.body);
  // Check validation
  if (!isValid) {
    return res.status(400).json(errors);
  }
  User.findOne({email: req.body.email}).then((user) => {
    if (user) {
      return res.status(400).json({email: 'Email already exists'});
    } else {
      const newUser = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        role: req.body.role,
      });
      // Hash password before saving in database
      bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt, (err, hash) => {
          if (err) throw err;
          newUser.password = hash;
          newUser
            .save()
            .then((user) => res.json(user))
            .then((user) => {
              const mailOptions = {
                from: 'rs2321994@gmail.com', // sender address
                to: 'asdasdsadasdasdasdadsadasdasd@sda.dasd', // list of receivers newUser.email
                subject: 'Welcome To vorkinsta', // Subject line
                html: '<p>Welcome to vorkinsta</p>', // plain text body
              };

              transporter.sendMail(mailOptions, function (err, info) {
                if (err) console.log(err);
                else console.log(info);
              });
            })
            .catch((err) => console.log(err));
        });
      });
    }
  });
};

exports.loginuser = async (req, res) => {
  const {errors, isValid} = validateLoginInput(req.body);
  // Check validation
  if (!isValid) {
    return res.status(400).json(errors);
  }
  const email = req.body.email;
  const password = req.body.password;
  // Find user by email
  User.findOne({email}).then((user) => {
    // Check if user exists
    if (!user) {
      return res.status(404).json({emailnotfound: 'Email not found'});
    }
    // Check password
    bcrypt.compare(password, user.password).then((isMatch) => {
      if (isMatch) {
        // User matched
        // Create JWT Payload
        const payload = {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
        };
        // Sign token
        jwt.sign(
          payload,
          keys.secretOrKey,
          {
            expiresIn: 31556926, // 1 year in seconds
          },
          (err, token) => {
            res.json({
              success: true,
              token: 'Bearer ' + token,
              User: user.role,
            });
          }
        );
      } else {
        return res.status(400).json({passwordincorrect: 'Password incorrect'});
      }
    });
  });
};

exports.getallusers = async (req, res) => {
  try {
    const datatobesend = await User.find({role: 'freelancer'});
    const name = datatobesend.map((data) => {
      const returobj = {
        name: data.name,
        email: data.email,
        id: data._id,
        Membersince: data.date,
      };

      return returobj;
    });
    res.status(200).send({message: 'Get all user', data: name});
  } catch (error) {
    res
      .status(400)
      .send({message: 'Not abote to find a any freelancer for you'});
  }
};

exports.getuserbyids = async (req, res) => {
  const id = req.params.id;
  try {
    const datatobesend = await User.findById(id);

    const returobj = {
      name: datatobesend.name,
      email: datatobesend.email,
      id: datatobesend._id,
      membersince: datatobesend.date,
    };

    res.status(200).send({message: 'Get a user', data: returobj});
  } catch (error) {
    res.status(400).send({message: 'Detail is not available'});
  }
};

exports.updateuser = async (req, res) => {
  const id = req.params.id;
  const Datatobeupdate = req.body;
  try {
    const updateData = await Job.findByIdAndUpdate(id, {
      $set: Datatobeupdate,
    });
    res
      .status(200)
      .send({Message: 'Data Update sucessfully', data: updateData});
  } catch (error) {
    res.status(400).send({Message: 'Not able to update a data ', data: error});
  }
};

exports.resettocken = async (req, res) => {
  const data = req.body;
  console.log(data);

  try {
    const dataidtobeupate = await User.find(data);
    function makeid(length) {
      var result = '';
      var characters =
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var charactersLength = characters.length;
      for (var i = 0; i < length; i++) {
        result += characters.charAt(
          Math.floor(Math.random() * charactersLength)
        );
      }
      return result;
    }

    const randomtockan = await makeid(7);
    let updatedobj = {resettocken: randomtockan};
    console.log(updatedobj);
    console.log(dataidtobeupate[0]._id);
    const objupdate = await User.findByIdAndUpdate(dataidtobeupate[0]._id, {
      $set: updatedobj,
    });

    const mailOptions = {
      from: 'rs2321994@gmail.com', // sender address
      to: dataidtobeupate[0].email, // list of receivers
      subject: 'Your reset Token To vorkinsta', // Subject line
      html: `<p>Your Reset tockan is ${randomtockan} </p>`, // plain text body
    };

    const sendmail = await transporter.sendMail(mailOptions);
    console.log(sendmail);
    res
      .status(200)
      .send({message: 'Please chack Email', data: sendmail.response});
  } catch (error) {
    res.status(400).send({message: 'Not Able to find a email'});
  }
};

//
