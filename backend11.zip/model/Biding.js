const mongoose = require('mongoose');

// Create Schema
const BeedingSchema = mongoose.Schema({
  Bidingpostid: {
    type: String,
    require: true,
  },
  BiderUserID: {
    type: String,
    require: true,
    unique: true,
  },
  BiderUsername: {
    type: String,
    require: true,
    unique: true,
  },
  BidingDescription: {
    type: String,
    require: true,
  },
  BidingPrice: {
    type: Number,
    require: true,
  },
  jobcreatoruserID: {
    type: String,
    require: true,
  },
  jobTitle: {
    type: String,
    require: true,
  },
  JobStatus: {
    type: String,
  },
  date: {
    type: Date,
    default: Date.now,
  },
});
module.exports = mongoose.model('bid', BeedingSchema);
