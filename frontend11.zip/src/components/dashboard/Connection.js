import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import axios from "axios";

class Connection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      requirenmentbids: [],
      show: false,
      AssignedBid: [],
      showAssignJobs: false
    };
  }

  acceptthisjob = e => {
    console.log(e.target.value);
  };

  deletthis = async e => {
    let Id = e.target.value;
    // console.log(Id);
    const { user } = this.props.auth;
    const userID = user.id;

    // console.log(userID);
    const deletbid = await axios.delete("/api/deletBid/" + Id);
    const getmyrequirenmentBid = await axios.get(
      "/app/getbids/creator/" + userID
    );
    const myPostBidding = getmyrequirenmentBid.data.data;

    this.setState({ requirenmentbids: myPostBidding });

    console.log(deletbid);
  };
  componentDidMount = async () => {
    const { user } = this.props.auth;
    const userID = user.id;
    // const AssignJobs = await axios.get('/api/assignjob/freelancer/' + userID);
    // console.log(AssignJobs.data.data);
    // if (user.role === 'freelancer') {
    //   const fetcheddata = await axios.get(
    //     '/api/assignjob/freelancer/' + userID
    //   );

    //   console.log(fetcheddata);
    // } else if (user.role === 'client') {
    //   const {user} = this.props.auth;
    //   const userID = user.id;

    //   const fetcheddata = await axios.get('/api/assignjob/client/' + userID);
    //   console.log(fetcheddata.data.data);
    // } else {
    //   console.log('Somthing Goes wrong');
    // }

    const getmyrequirenmentBid = await axios.get(
      "/app/getbids/creator/" + userID
    );

    const myPostBidding = getmyrequirenmentBid.data.data;
    // console.log(myPostBidding);
    if (getmyrequirenmentBid.data.data[0] === undefined) {
      this.setState({ show: false });
    } else {
      this.setState({ requirenmentbids: myPostBidding });
      this.setState({ show: true });
      console.log(this.state.requirenmentbids);
    }

    const GetMyAssignJobs = await axios.get("/api/getanyuser/" + userID);
    const assignjobs = GetMyAssignJobs.data.data;
    console.log(assignjobs);
    if (assignjobs === undefined) {
      this.setState({ assignjobs: false });
    } else {
      this.setState({ AssignedBid: GetMyAssignJobs });
      this.setState({ assignjobs: true });
    }
  };

  render() {
    const { user } = this.props.auth;
    return (
      <div>
        <div class="container">
          <div class="row">
            <div class="col-sm-9">
              <div class="card">
                <div class="card-header">
                  <b>My Requirenmets Bids</b>
                </div>
                <div class="card-body">
                  {this.state.show ? (
                    this.state.requirenmentbids.map(el => {
                      return (
                        <div>
                          <div class="card">
                            <div class="card-body">
                              <h5 class="card-title">
                                <b>{el.jobTitle}</b>
                              </h5>
                              <h6 class="card-subtitle mb-2 text-muted">
                                User-Name:{el.BiderUsername}/ BiddingPrice:
                                {el.BidingPrice}
                              </h6>
                              <p class="card-text">{el.BidingDescription}</p>
                              <button
                                type="button"
                                class="btn btn-success"
                                value={el._id}
                                onClick={this.acceptthisjob}
                              >
                                Accept
                              </button>
                              <button
                                type="button"
                                class="btn btn-danger"
                                style={{ marginLeft: "10px" }}
                                value={el._id}
                                onClick={this.deletthis}
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <h6>No Bid Found On Your Any Post</h6>
                  )}
                </div>
              </div>
              <hr />
              <div class="card">
                <div class="card-header">
                  <b>Assigned Jobs</b>
                </div>
                <div class="card-body">
                  {this.state.showAssignJobs ? (
                    this.state.AssignedBid.map(el => {
                      return (
                        <div>
                          <div class="card">
                            <div class="card-body">
                              <h5 class="card-title">
                                <b>{el.JobID}</b>
                              </h5>
                              <h6 class="card-subtitle mb-2 text-muted">
                                Boss Name:JobcreatorUserName
                              </h6>
                              <p class="card-text">
                                AssignUser Name:{el.JobAssigntoUserName}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <h6>No Job Assigned </h6>
                  )}
                </div>
              </div>
            </div>
            <div class="col-sm-3">
              <div class="card">
                <div class="card-body">
                  <h5>
                    <b>Suggetions</b>
                  </h5>
                  <hr />
                  <a>
                    <h6>react js</h6>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

Connection.propTypes = {
  auth: PropTypes.object.isRequired
};

const mapStateToProps = state => ({
  auth: state.auth
});

export default connect(mapStateToProps)(Connection);
